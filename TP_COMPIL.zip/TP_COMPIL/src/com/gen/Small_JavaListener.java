// Generated from C:/Users/dell/IdeaProjects/TP_COMPIL\Small_Java.g4 by ANTLR 4.7.2
package com.gen;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link Small_JavaParser}.
 */
public interface Small_JavaListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#r}.
	 * @param ctx the parse tree
	 */
	void enterR(Small_JavaParser.RContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#r}.
	 * @param ctx the parse tree
	 */
	void exitR(Small_JavaParser.RContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#import_bib}.
	 * @param ctx the parse tree
	 */
	void enterImport_bib(Small_JavaParser.Import_bibContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#import_bib}.
	 * @param ctx the parse tree
	 */
	void exitImport_bib(Small_JavaParser.Import_bibContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#class_declare}.
	 * @param ctx the parse tree
	 */
	void enterClass_declare(Small_JavaParser.Class_declareContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#class_declare}.
	 * @param ctx the parse tree
	 */
	void exitClass_declare(Small_JavaParser.Class_declareContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#class_content}.
	 * @param ctx the parse tree
	 */
	void enterClass_content(Small_JavaParser.Class_contentContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#class_content}.
	 * @param ctx the parse tree
	 */
	void exitClass_content(Small_JavaParser.Class_contentContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#vars_declare}.
	 * @param ctx the parse tree
	 */
	void enterVars_declare(Small_JavaParser.Vars_declareContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#vars_declare}.
	 * @param ctx the parse tree
	 */
	void exitVars_declare(Small_JavaParser.Vars_declareContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#main}.
	 * @param ctx the parse tree
	 */
	void enterMain(Small_JavaParser.MainContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#main}.
	 * @param ctx the parse tree
	 */
	void exitMain(Small_JavaParser.MainContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterInstruction(Small_JavaParser.InstructionContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitInstruction(Small_JavaParser.InstructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#instruction2}.
	 * @param ctx the parse tree
	 */
	void enterInstruction2(Small_JavaParser.Instruction2Context ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#instruction2}.
	 * @param ctx the parse tree
	 */
	void exitInstruction2(Small_JavaParser.Instruction2Context ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#assign}.
	 * @param ctx the parse tree
	 */
	void enterAssign(Small_JavaParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#assign}.
	 * @param ctx the parse tree
	 */
	void exitAssign(Small_JavaParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#if_cond}.
	 * @param ctx the parse tree
	 */
	void enterIf_cond(Small_JavaParser.If_condContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#if_cond}.
	 * @param ctx the parse tree
	 */
	void exitIf_cond(Small_JavaParser.If_condContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#read}.
	 * @param ctx the parse tree
	 */
	void enterRead(Small_JavaParser.ReadContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#read}.
	 * @param ctx the parse tree
	 */
	void exitRead(Small_JavaParser.ReadContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#write}.
	 * @param ctx the parse tree
	 */
	void enterWrite(Small_JavaParser.WriteContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#write}.
	 * @param ctx the parse tree
	 */
	void exitWrite(Small_JavaParser.WriteContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(Small_JavaParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(Small_JavaParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#factor}.
	 * @param ctx the parse tree
	 */
	void enterFactor(Small_JavaParser.FactorContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#factor}.
	 * @param ctx the parse tree
	 */
	void exitFactor(Small_JavaParser.FactorContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#v}.
	 * @param ctx the parse tree
	 */
	void enterV(Small_JavaParser.VContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#v}.
	 * @param ctx the parse tree
	 */
	void exitV(Small_JavaParser.VContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#exp_b}.
	 * @param ctx the parse tree
	 */
	void enterExp_b(Small_JavaParser.Exp_bContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#exp_b}.
	 * @param ctx the parse tree
	 */
	void exitExp_b(Small_JavaParser.Exp_bContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#factor_b}.
	 * @param ctx the parse tree
	 */
	void enterFactor_b(Small_JavaParser.Factor_bContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#factor_b}.
	 * @param ctx the parse tree
	 */
	void exitFactor_b(Small_JavaParser.Factor_bContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#literal}.
	 * @param ctx the parse tree
	 */
	void enterLiteral(Small_JavaParser.LiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#literal}.
	 * @param ctx the parse tree
	 */
	void exitLiteral(Small_JavaParser.LiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterAtom(Small_JavaParser.AtomContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitAtom(Small_JavaParser.AtomContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#var_declare}.
	 * @param ctx the parse tree
	 */
	void enterVar_declare(Small_JavaParser.Var_declareContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#var_declare}.
	 * @param ctx the parse tree
	 */
	void exitVar_declare(Small_JavaParser.Var_declareContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#bibs}.
	 * @param ctx the parse tree
	 */
	void enterBibs(Small_JavaParser.BibsContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#bibs}.
	 * @param ctx the parse tree
	 */
	void exitBibs(Small_JavaParser.BibsContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(Small_JavaParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(Small_JavaParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#modif}.
	 * @param ctx the parse tree
	 */
	void enterModif(Small_JavaParser.ModifContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#modif}.
	 * @param ctx the parse tree
	 */
	void exitModif(Small_JavaParser.ModifContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#string}.
	 * @param ctx the parse tree
	 */
	void enterString(Small_JavaParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#string}.
	 * @param ctx the parse tree
	 */
	void exitString(Small_JavaParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#op_compare}.
	 * @param ctx the parse tree
	 */
	void enterOp_compare(Small_JavaParser.Op_compareContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#op_compare}.
	 * @param ctx the parse tree
	 */
	void exitOp_compare(Small_JavaParser.Op_compareContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#mul_div}.
	 * @param ctx the parse tree
	 */
	void enterMul_div(Small_JavaParser.Mul_divContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#mul_div}.
	 * @param ctx the parse tree
	 */
	void exitMul_div(Small_JavaParser.Mul_divContext ctx);
	/**
	 * Enter a parse tree produced by {@link Small_JavaParser#plus_minus}.
	 * @param ctx the parse tree
	 */
	void enterPlus_minus(Small_JavaParser.Plus_minusContext ctx);
	/**
	 * Exit a parse tree produced by {@link Small_JavaParser#plus_minus}.
	 * @param ctx the parse tree
	 */
	void exitPlus_minus(Small_JavaParser.Plus_minusContext ctx);
}