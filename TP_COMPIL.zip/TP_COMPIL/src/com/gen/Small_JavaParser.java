// Generated from C:/Users/dell/IdeaProjects/TP_COMPIL\Small_Java.g4 by ANTLR 4.7.2
package com.gen;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class Small_JavaParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IMPORT_KW=1, CLASS_KW=2, MAIN_KW=3, IN_KW=4, OUT_KW=5, IF_KW=6, ELSE_KW=7, 
		THEN_KW=8, PLUS=9, MINUS=10, MUL=11, DIV=12, G=13, GE=14, L=15, LE=16, 
		E=17, NE=18, NOT=19, AND=20, OR=21, ASSIGN=22, PAR_B=23, PAR_E=24, ACC_B=25, 
		ACC_E=26, COMMA=27, SEMICOLON=28, MODIF_PUBLIC=29, MODIF_PROTECTED=30, 
		BIB_LANG=31, BIB_IO=32, TYPE_INT=33, TYPE_FLOAT=34, TYPE_STRING=35, INT=36, 
		FLOAT=37, CLASS_IDF=38, IDF=39, STRING=40, WS=41;
	public static final int
		RULE_r = 0, RULE_import_bib = 1, RULE_class_declare = 2, RULE_class_content = 3, 
		RULE_vars_declare = 4, RULE_main = 5, RULE_instruction = 6, RULE_instruction2 = 7, 
		RULE_assign = 8, RULE_if_cond = 9, RULE_read = 10, RULE_write = 11, RULE_exp = 12, 
		RULE_factor = 13, RULE_v = 14, RULE_exp_b = 15, RULE_factor_b = 16, RULE_literal = 17, 
		RULE_atom = 18, RULE_var_declare = 19, RULE_bibs = 20, RULE_type = 21, 
		RULE_modif = 22, RULE_string = 23, RULE_op_compare = 24, RULE_mul_div = 25, 
		RULE_plus_minus = 26;
	private static String[] makeRuleNames() {
		return new String[] {
			"r", "import_bib", "class_declare", "class_content", "vars_declare", 
			"main", "instruction", "instruction2", "assign", "if_cond", "read", "write", 
			"exp", "factor", "v", "exp_b", "factor_b", "literal", "atom", "var_declare", 
			"bibs", "type", "modif", "string", "op_compare", "mul_div", "plus_minus"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'import'", "'class_SJ'", "'main_SJ'", "'In_SJ'", "'Out_SJ'", "'if'", 
			"'else'", "'then'", "'+'", "'-'", "'*'", "'/'", "'>'", "'>='", "'<'", 
			"'<='", "'='", "'!='", "'!'", "'&'", "'|'", "':='", "'('", "')'", "'{'", 
			"'}'", "','", "';'", "'public'", "'protected'", "'Small_Java.lang'", 
			"'Small_Java.io'", "'int_SJ'", "'float_SJ'", "'string_SJ'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IMPORT_KW", "CLASS_KW", "MAIN_KW", "IN_KW", "OUT_KW", "IF_KW", 
			"ELSE_KW", "THEN_KW", "PLUS", "MINUS", "MUL", "DIV", "G", "GE", "L", 
			"LE", "E", "NE", "NOT", "AND", "OR", "ASSIGN", "PAR_B", "PAR_E", "ACC_B", 
			"ACC_E", "COMMA", "SEMICOLON", "MODIF_PUBLIC", "MODIF_PROTECTED", "BIB_LANG", 
			"BIB_IO", "TYPE_INT", "TYPE_FLOAT", "TYPE_STRING", "INT", "FLOAT", "CLASS_IDF", 
			"IDF", "STRING", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Small_Java.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public Small_JavaParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class RContext extends ParserRuleContext {
		public Import_bibContext import_bib() {
			return getRuleContext(Import_bibContext.class,0);
		}
		public Class_declareContext class_declare() {
			return getRuleContext(Class_declareContext.class,0);
		}
		public RContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_r; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterR(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitR(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitR(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RContext r() throws RecognitionException {
		RContext _localctx = new RContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_r);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(54);
			import_bib();
			setState(55);
			class_declare();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Import_bibContext extends ParserRuleContext {
		public List<TerminalNode> IMPORT_KW() { return getTokens(Small_JavaParser.IMPORT_KW); }
		public TerminalNode IMPORT_KW(int i) {
			return getToken(Small_JavaParser.IMPORT_KW, i);
		}
		public List<BibsContext> bibs() {
			return getRuleContexts(BibsContext.class);
		}
		public BibsContext bibs(int i) {
			return getRuleContext(BibsContext.class,i);
		}
		public List<TerminalNode> SEMICOLON() { return getTokens(Small_JavaParser.SEMICOLON); }
		public TerminalNode SEMICOLON(int i) {
			return getToken(Small_JavaParser.SEMICOLON, i);
		}
		public Import_bibContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_import_bib; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterImport_bib(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitImport_bib(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitImport_bib(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Import_bibContext import_bib() throws RecognitionException {
		Import_bibContext _localctx = new Import_bibContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_import_bib);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(63);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IMPORT_KW) {
				{
				{
				setState(57);
				match(IMPORT_KW);
				setState(58);
				bibs();
				setState(59);
				match(SEMICOLON);
				}
				}
				setState(65);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Class_declareContext extends ParserRuleContext {
		public ModifContext modif() {
			return getRuleContext(ModifContext.class,0);
		}
		public TerminalNode CLASS_KW() { return getToken(Small_JavaParser.CLASS_KW, 0); }
		public TerminalNode CLASS_IDF() { return getToken(Small_JavaParser.CLASS_IDF, 0); }
		public TerminalNode ACC_B() { return getToken(Small_JavaParser.ACC_B, 0); }
		public Class_contentContext class_content() {
			return getRuleContext(Class_contentContext.class,0);
		}
		public TerminalNode ACC_E() { return getToken(Small_JavaParser.ACC_E, 0); }
		public Class_declareContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_class_declare; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterClass_declare(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitClass_declare(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitClass_declare(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Class_declareContext class_declare() throws RecognitionException {
		Class_declareContext _localctx = new Class_declareContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_class_declare);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(66);
			modif();
			setState(67);
			match(CLASS_KW);
			setState(68);
			match(CLASS_IDF);
			setState(69);
			match(ACC_B);
			setState(70);
			class_content();
			setState(71);
			match(ACC_E);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Class_contentContext extends ParserRuleContext {
		public Vars_declareContext vars_declare() {
			return getRuleContext(Vars_declareContext.class,0);
		}
		public MainContext main() {
			return getRuleContext(MainContext.class,0);
		}
		public Class_contentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_class_content; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterClass_content(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitClass_content(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitClass_content(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Class_contentContext class_content() throws RecognitionException {
		Class_contentContext _localctx = new Class_contentContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_class_content);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			vars_declare();
			setState(74);
			main();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Vars_declareContext extends ParserRuleContext {
		public List<Var_declareContext> var_declare() {
			return getRuleContexts(Var_declareContext.class);
		}
		public Var_declareContext var_declare(int i) {
			return getRuleContext(Var_declareContext.class,i);
		}
		public Vars_declareContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vars_declare; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterVars_declare(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitVars_declare(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitVars_declare(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Vars_declareContext vars_declare() throws RecognitionException {
		Vars_declareContext _localctx = new Vars_declareContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_vars_declare);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TYPE_INT) | (1L << TYPE_FLOAT) | (1L << TYPE_STRING))) != 0)) {
				{
				{
				setState(76);
				var_declare();
				}
				}
				setState(81);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MainContext extends ParserRuleContext {
		public TerminalNode MAIN_KW() { return getToken(Small_JavaParser.MAIN_KW, 0); }
		public TerminalNode ACC_B() { return getToken(Small_JavaParser.ACC_B, 0); }
		public TerminalNode ACC_E() { return getToken(Small_JavaParser.ACC_E, 0); }
		public List<InstructionContext> instruction() {
			return getRuleContexts(InstructionContext.class);
		}
		public InstructionContext instruction(int i) {
			return getRuleContext(InstructionContext.class,i);
		}
		public MainContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_main; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterMain(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitMain(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitMain(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MainContext main() throws RecognitionException {
		MainContext _localctx = new MainContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_main);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(82);
			match(MAIN_KW);
			setState(83);
			match(ACC_B);
			setState(87);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IN_KW) | (1L << OUT_KW) | (1L << IF_KW) | (1L << IDF))) != 0)) {
				{
				{
				setState(84);
				instruction();
				}
				}
				setState(89);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(90);
			match(ACC_E);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionContext extends ParserRuleContext {
		public AssignContext assign() {
			return getRuleContext(AssignContext.class,0);
		}
		public If_condContext if_cond() {
			return getRuleContext(If_condContext.class,0);
		}
		public ReadContext read() {
			return getRuleContext(ReadContext.class,0);
		}
		public WriteContext write() {
			return getRuleContext(WriteContext.class,0);
		}
		public InstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instruction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterInstruction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitInstruction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitInstruction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstructionContext instruction() throws RecognitionException {
		InstructionContext _localctx = new InstructionContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_instruction);
		try {
			setState(96);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDF:
				enterOuterAlt(_localctx, 1);
				{
				setState(92);
				assign();
				}
				break;
			case IF_KW:
				enterOuterAlt(_localctx, 2);
				{
				setState(93);
				if_cond();
				}
				break;
			case IN_KW:
				enterOuterAlt(_localctx, 3);
				{
				setState(94);
				read();
				}
				break;
			case OUT_KW:
				enterOuterAlt(_localctx, 4);
				{
				setState(95);
				write();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Instruction2Context extends ParserRuleContext {
		public InstructionContext instruction() {
			return getRuleContext(InstructionContext.class,0);
		}
		public Instruction2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instruction2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterInstruction2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitInstruction2(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitInstruction2(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Instruction2Context instruction2() throws RecognitionException {
		Instruction2Context _localctx = new Instruction2Context(_ctx, getState());
		enterRule(_localctx, 14, RULE_instruction2);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(98);
			instruction();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignContext extends ParserRuleContext {
		public TerminalNode IDF() { return getToken(Small_JavaParser.IDF, 0); }
		public TerminalNode ASSIGN() { return getToken(Small_JavaParser.ASSIGN, 0); }
		public TerminalNode SEMICOLON() { return getToken(Small_JavaParser.SEMICOLON, 0); }
		public Exp_bContext exp_b() {
			return getRuleContext(Exp_bContext.class,0);
		}
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public AssignContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assign; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterAssign(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitAssign(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitAssign(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignContext assign() throws RecognitionException {
		AssignContext _localctx = new AssignContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_assign);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(100);
			match(IDF);
			setState(101);
			match(ASSIGN);
			setState(104);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MINUS:
			case NOT:
			case PAR_B:
			case INT:
			case FLOAT:
			case IDF:
				{
				setState(102);
				exp_b();
				}
				break;
			case STRING:
				{
				setState(103);
				string();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(106);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class If_condContext extends ParserRuleContext {
		public TerminalNode IF_KW() { return getToken(Small_JavaParser.IF_KW, 0); }
		public TerminalNode PAR_B() { return getToken(Small_JavaParser.PAR_B, 0); }
		public Exp_bContext exp_b() {
			return getRuleContext(Exp_bContext.class,0);
		}
		public TerminalNode PAR_E() { return getToken(Small_JavaParser.PAR_E, 0); }
		public TerminalNode THEN_KW() { return getToken(Small_JavaParser.THEN_KW, 0); }
		public List<TerminalNode> ACC_B() { return getTokens(Small_JavaParser.ACC_B); }
		public TerminalNode ACC_B(int i) {
			return getToken(Small_JavaParser.ACC_B, i);
		}
		public List<TerminalNode> ACC_E() { return getTokens(Small_JavaParser.ACC_E); }
		public TerminalNode ACC_E(int i) {
			return getToken(Small_JavaParser.ACC_E, i);
		}
		public List<InstructionContext> instruction() {
			return getRuleContexts(InstructionContext.class);
		}
		public InstructionContext instruction(int i) {
			return getRuleContext(InstructionContext.class,i);
		}
		public TerminalNode ELSE_KW() { return getToken(Small_JavaParser.ELSE_KW, 0); }
		public List<Instruction2Context> instruction2() {
			return getRuleContexts(Instruction2Context.class);
		}
		public Instruction2Context instruction2(int i) {
			return getRuleContext(Instruction2Context.class,i);
		}
		public If_condContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_if_cond; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterIf_cond(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitIf_cond(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitIf_cond(this);
			else return visitor.visitChildren(this);
		}
	}

	public final If_condContext if_cond() throws RecognitionException {
		If_condContext _localctx = new If_condContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_if_cond);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(108);
			match(IF_KW);
			setState(109);
			match(PAR_B);
			setState(110);
			exp_b();
			setState(111);
			match(PAR_E);
			setState(112);
			match(THEN_KW);
			setState(113);
			match(ACC_B);
			setState(117);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IN_KW) | (1L << OUT_KW) | (1L << IF_KW) | (1L << IDF))) != 0)) {
				{
				{
				setState(114);
				instruction();
				}
				}
				setState(119);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(120);
			match(ACC_E);
			setState(130);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE_KW) {
				{
				setState(121);
				match(ELSE_KW);
				setState(122);
				match(ACC_B);
				setState(126);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << IN_KW) | (1L << OUT_KW) | (1L << IF_KW) | (1L << IDF))) != 0)) {
					{
					{
					setState(123);
					instruction2();
					}
					}
					setState(128);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(129);
				match(ACC_E);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ReadContext extends ParserRuleContext {
		public TerminalNode IN_KW() { return getToken(Small_JavaParser.IN_KW, 0); }
		public TerminalNode PAR_B() { return getToken(Small_JavaParser.PAR_B, 0); }
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(Small_JavaParser.COMMA, 0); }
		public TerminalNode IDF() { return getToken(Small_JavaParser.IDF, 0); }
		public TerminalNode PAR_E() { return getToken(Small_JavaParser.PAR_E, 0); }
		public TerminalNode SEMICOLON() { return getToken(Small_JavaParser.SEMICOLON, 0); }
		public ReadContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_read; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterRead(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitRead(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitRead(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ReadContext read() throws RecognitionException {
		ReadContext _localctx = new ReadContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_read);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(132);
			match(IN_KW);
			setState(133);
			match(PAR_B);
			setState(134);
			string();
			setState(135);
			match(COMMA);
			setState(136);
			match(IDF);
			setState(137);
			match(PAR_E);
			setState(138);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WriteContext extends ParserRuleContext {
		public TerminalNode OUT_KW() { return getToken(Small_JavaParser.OUT_KW, 0); }
		public TerminalNode PAR_B() { return getToken(Small_JavaParser.PAR_B, 0); }
		public StringContext string() {
			return getRuleContext(StringContext.class,0);
		}
		public TerminalNode PAR_E() { return getToken(Small_JavaParser.PAR_E, 0); }
		public TerminalNode SEMICOLON() { return getToken(Small_JavaParser.SEMICOLON, 0); }
		public List<TerminalNode> COMMA() { return getTokens(Small_JavaParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(Small_JavaParser.COMMA, i);
		}
		public List<Exp_bContext> exp_b() {
			return getRuleContexts(Exp_bContext.class);
		}
		public Exp_bContext exp_b(int i) {
			return getRuleContext(Exp_bContext.class,i);
		}
		public WriteContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_write; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterWrite(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitWrite(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitWrite(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WriteContext write() throws RecognitionException {
		WriteContext _localctx = new WriteContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_write);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(140);
			match(OUT_KW);
			setState(141);
			match(PAR_B);
			setState(142);
			string();
			setState(147);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(143);
				match(COMMA);
				setState(144);
				exp_b();
				}
				}
				setState(149);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(150);
			match(PAR_E);
			setState(151);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpContext extends ParserRuleContext {
		public List<FactorContext> factor() {
			return getRuleContexts(FactorContext.class);
		}
		public FactorContext factor(int i) {
			return getRuleContext(FactorContext.class,i);
		}
		public TerminalNode MINUS() { return getToken(Small_JavaParser.MINUS, 0); }
		public List<Plus_minusContext> plus_minus() {
			return getRuleContexts(Plus_minusContext.class);
		}
		public Plus_minusContext plus_minus(int i) {
			return getRuleContext(Plus_minusContext.class,i);
		}
		public ExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpContext exp() throws RecognitionException {
		ExpContext _localctx = new ExpContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_exp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(154);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==MINUS) {
				{
				setState(153);
				match(MINUS);
				}
			}

			setState(156);
			factor();
			setState(162);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==PLUS || _la==MINUS) {
				{
				{
				setState(157);
				plus_minus();
				setState(158);
				factor();
				}
				}
				setState(164);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FactorContext extends ParserRuleContext {
		public List<VContext> v() {
			return getRuleContexts(VContext.class);
		}
		public VContext v(int i) {
			return getRuleContext(VContext.class,i);
		}
		public List<Mul_divContext> mul_div() {
			return getRuleContexts(Mul_divContext.class);
		}
		public Mul_divContext mul_div(int i) {
			return getRuleContext(Mul_divContext.class,i);
		}
		public FactorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterFactor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitFactor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitFactor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FactorContext factor() throws RecognitionException {
		FactorContext _localctx = new FactorContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_factor);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(165);
			v();
			setState(171);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==MUL || _la==DIV) {
				{
				{
				setState(166);
				mul_div();
				setState(167);
				v();
				}
				}
				setState(173);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VContext extends ParserRuleContext {
		public TerminalNode INT() { return getToken(Small_JavaParser.INT, 0); }
		public TerminalNode FLOAT() { return getToken(Small_JavaParser.FLOAT, 0); }
		public TerminalNode IDF() { return getToken(Small_JavaParser.IDF, 0); }
		public TerminalNode PAR_B() { return getToken(Small_JavaParser.PAR_B, 0); }
		public ExpContext exp() {
			return getRuleContext(ExpContext.class,0);
		}
		public TerminalNode PAR_E() { return getToken(Small_JavaParser.PAR_E, 0); }
		public VContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_v; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterV(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitV(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitV(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VContext v() throws RecognitionException {
		VContext _localctx = new VContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_v);
		try {
			setState(181);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case INT:
				enterOuterAlt(_localctx, 1);
				{
				setState(174);
				match(INT);
				}
				break;
			case FLOAT:
				enterOuterAlt(_localctx, 2);
				{
				setState(175);
				match(FLOAT);
				}
				break;
			case IDF:
				enterOuterAlt(_localctx, 3);
				{
				setState(176);
				match(IDF);
				}
				break;
			case PAR_B:
				enterOuterAlt(_localctx, 4);
				{
				setState(177);
				match(PAR_B);
				setState(178);
				exp();
				setState(179);
				match(PAR_E);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Exp_bContext extends ParserRuleContext {
		public List<Factor_bContext> factor_b() {
			return getRuleContexts(Factor_bContext.class);
		}
		public Factor_bContext factor_b(int i) {
			return getRuleContext(Factor_bContext.class,i);
		}
		public List<TerminalNode> OR() { return getTokens(Small_JavaParser.OR); }
		public TerminalNode OR(int i) {
			return getToken(Small_JavaParser.OR, i);
		}
		public Exp_bContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exp_b; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterExp_b(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitExp_b(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitExp_b(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Exp_bContext exp_b() throws RecognitionException {
		Exp_bContext _localctx = new Exp_bContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_exp_b);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(183);
			factor_b();
			setState(188);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==OR) {
				{
				{
				setState(184);
				match(OR);
				setState(185);
				factor_b();
				}
				}
				setState(190);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Factor_bContext extends ParserRuleContext {
		public List<LiteralContext> literal() {
			return getRuleContexts(LiteralContext.class);
		}
		public LiteralContext literal(int i) {
			return getRuleContext(LiteralContext.class,i);
		}
		public List<TerminalNode> AND() { return getTokens(Small_JavaParser.AND); }
		public TerminalNode AND(int i) {
			return getToken(Small_JavaParser.AND, i);
		}
		public Factor_bContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_factor_b; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterFactor_b(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitFactor_b(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitFactor_b(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Factor_bContext factor_b() throws RecognitionException {
		Factor_bContext _localctx = new Factor_bContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_factor_b);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(191);
			literal();
			setState(196);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AND) {
				{
				{
				setState(192);
				match(AND);
				setState(193);
				literal();
				}
				}
				setState(198);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public TerminalNode NOT() { return getToken(Small_JavaParser.NOT, 0); }
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(200);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(199);
				match(NOT);
				}
			}

			setState(202);
			atom();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtomContext extends ParserRuleContext {
		public List<ExpContext> exp() {
			return getRuleContexts(ExpContext.class);
		}
		public ExpContext exp(int i) {
			return getRuleContext(ExpContext.class,i);
		}
		public List<Op_compareContext> op_compare() {
			return getRuleContexts(Op_compareContext.class);
		}
		public Op_compareContext op_compare(int i) {
			return getRuleContext(Op_compareContext.class,i);
		}
		public TerminalNode PAR_B() { return getToken(Small_JavaParser.PAR_B, 0); }
		public Exp_bContext exp_b() {
			return getRuleContext(Exp_bContext.class,0);
		}
		public TerminalNode PAR_E() { return getToken(Small_JavaParser.PAR_E, 0); }
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_atom);
		int _la;
		try {
			setState(217);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,17,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(204);
				exp();
				setState(210);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << G) | (1L << GE) | (1L << L) | (1L << LE) | (1L << E) | (1L << NE))) != 0)) {
					{
					{
					setState(205);
					op_compare();
					setState(206);
					exp();
					}
					}
					setState(212);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(213);
				match(PAR_B);
				setState(214);
				exp_b();
				setState(215);
				match(PAR_E);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Var_declareContext extends ParserRuleContext {
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public List<TerminalNode> IDF() { return getTokens(Small_JavaParser.IDF); }
		public TerminalNode IDF(int i) {
			return getToken(Small_JavaParser.IDF, i);
		}
		public TerminalNode SEMICOLON() { return getToken(Small_JavaParser.SEMICOLON, 0); }
		public List<TerminalNode> COMMA() { return getTokens(Small_JavaParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(Small_JavaParser.COMMA, i);
		}
		public Var_declareContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var_declare; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterVar_declare(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitVar_declare(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitVar_declare(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Var_declareContext var_declare() throws RecognitionException {
		Var_declareContext _localctx = new Var_declareContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_var_declare);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(219);
			type();
			setState(220);
			match(IDF);
			setState(225);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(221);
				match(COMMA);
				setState(222);
				match(IDF);
				}
				}
				setState(227);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(228);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BibsContext extends ParserRuleContext {
		public TerminalNode BIB_IO() { return getToken(Small_JavaParser.BIB_IO, 0); }
		public TerminalNode BIB_LANG() { return getToken(Small_JavaParser.BIB_LANG, 0); }
		public BibsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bibs; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterBibs(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitBibs(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitBibs(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BibsContext bibs() throws RecognitionException {
		BibsContext _localctx = new BibsContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_bibs);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(230);
			_la = _input.LA(1);
			if ( !(_la==BIB_LANG || _la==BIB_IO) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public TerminalNode TYPE_INT() { return getToken(Small_JavaParser.TYPE_INT, 0); }
		public TerminalNode TYPE_FLOAT() { return getToken(Small_JavaParser.TYPE_FLOAT, 0); }
		public TerminalNode TYPE_STRING() { return getToken(Small_JavaParser.TYPE_STRING, 0); }
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_type);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(232);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TYPE_INT) | (1L << TYPE_FLOAT) | (1L << TYPE_STRING))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ModifContext extends ParserRuleContext {
		public TerminalNode MODIF_PUBLIC() { return getToken(Small_JavaParser.MODIF_PUBLIC, 0); }
		public TerminalNode MODIF_PROTECTED() { return getToken(Small_JavaParser.MODIF_PROTECTED, 0); }
		public ModifContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_modif; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterModif(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitModif(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitModif(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ModifContext modif() throws RecognitionException {
		ModifContext _localctx = new ModifContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_modif);
		int _la;
		try {
			setState(236);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case MODIF_PUBLIC:
			case MODIF_PROTECTED:
				enterOuterAlt(_localctx, 1);
				{
				setState(234);
				_la = _input.LA(1);
				if ( !(_la==MODIF_PUBLIC || _la==MODIF_PROTECTED) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_KW:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StringContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(Small_JavaParser.STRING, 0); }
		public StringContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterString(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitString(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitString(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StringContext string() throws RecognitionException {
		StringContext _localctx = new StringContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_string);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(238);
			match(STRING);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Op_compareContext extends ParserRuleContext {
		public TerminalNode G() { return getToken(Small_JavaParser.G, 0); }
		public TerminalNode GE() { return getToken(Small_JavaParser.GE, 0); }
		public TerminalNode L() { return getToken(Small_JavaParser.L, 0); }
		public TerminalNode LE() { return getToken(Small_JavaParser.LE, 0); }
		public TerminalNode E() { return getToken(Small_JavaParser.E, 0); }
		public TerminalNode NE() { return getToken(Small_JavaParser.NE, 0); }
		public Op_compareContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_op_compare; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterOp_compare(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitOp_compare(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitOp_compare(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Op_compareContext op_compare() throws RecognitionException {
		Op_compareContext _localctx = new Op_compareContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_op_compare);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(240);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << G) | (1L << GE) | (1L << L) | (1L << LE) | (1L << E) | (1L << NE))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Mul_divContext extends ParserRuleContext {
		public TerminalNode MUL() { return getToken(Small_JavaParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(Small_JavaParser.DIV, 0); }
		public Mul_divContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mul_div; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterMul_div(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitMul_div(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitMul_div(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Mul_divContext mul_div() throws RecognitionException {
		Mul_divContext _localctx = new Mul_divContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_mul_div);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(242);
			_la = _input.LA(1);
			if ( !(_la==MUL || _la==DIV) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Plus_minusContext extends ParserRuleContext {
		public TerminalNode PLUS() { return getToken(Small_JavaParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(Small_JavaParser.MINUS, 0); }
		public Plus_minusContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_plus_minus; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).enterPlus_minus(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof Small_JavaListener ) ((Small_JavaListener)listener).exitPlus_minus(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof Small_JavaVisitor ) return ((Small_JavaVisitor<? extends T>)visitor).visitPlus_minus(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Plus_minusContext plus_minus() throws RecognitionException {
		Plus_minusContext _localctx = new Plus_minusContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_plus_minus);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(244);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3+\u00f9\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\3\2\3\2\3\2\3\3\3\3\3\3\3\3\7\3@\n\3\f"+
		"\3\16\3C\13\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\5\3\5\3\5\3\6\7\6P\n\6\f\6"+
		"\16\6S\13\6\3\7\3\7\3\7\7\7X\n\7\f\7\16\7[\13\7\3\7\3\7\3\b\3\b\3\b\3"+
		"\b\5\bc\n\b\3\t\3\t\3\n\3\n\3\n\3\n\5\nk\n\n\3\n\3\n\3\13\3\13\3\13\3"+
		"\13\3\13\3\13\3\13\7\13v\n\13\f\13\16\13y\13\13\3\13\3\13\3\13\3\13\7"+
		"\13\177\n\13\f\13\16\13\u0082\13\13\3\13\5\13\u0085\n\13\3\f\3\f\3\f\3"+
		"\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\7\r\u0094\n\r\f\r\16\r\u0097\13"+
		"\r\3\r\3\r\3\r\3\16\5\16\u009d\n\16\3\16\3\16\3\16\3\16\7\16\u00a3\n\16"+
		"\f\16\16\16\u00a6\13\16\3\17\3\17\3\17\3\17\7\17\u00ac\n\17\f\17\16\17"+
		"\u00af\13\17\3\20\3\20\3\20\3\20\3\20\3\20\3\20\5\20\u00b8\n\20\3\21\3"+
		"\21\3\21\7\21\u00bd\n\21\f\21\16\21\u00c0\13\21\3\22\3\22\3\22\7\22\u00c5"+
		"\n\22\f\22\16\22\u00c8\13\22\3\23\5\23\u00cb\n\23\3\23\3\23\3\24\3\24"+
		"\3\24\3\24\7\24\u00d3\n\24\f\24\16\24\u00d6\13\24\3\24\3\24\3\24\3\24"+
		"\5\24\u00dc\n\24\3\25\3\25\3\25\3\25\7\25\u00e2\n\25\f\25\16\25\u00e5"+
		"\13\25\3\25\3\25\3\26\3\26\3\27\3\27\3\30\3\30\5\30\u00ef\n\30\3\31\3"+
		"\31\3\32\3\32\3\33\3\33\3\34\3\34\3\34\2\2\35\2\4\6\b\n\f\16\20\22\24"+
		"\26\30\32\34\36 \"$&(*,.\60\62\64\66\2\b\3\2!\"\3\2#%\3\2\37 \3\2\17\24"+
		"\3\2\r\16\3\2\13\f\2\u00f5\28\3\2\2\2\4A\3\2\2\2\6D\3\2\2\2\bK\3\2\2\2"+
		"\nQ\3\2\2\2\fT\3\2\2\2\16b\3\2\2\2\20d\3\2\2\2\22f\3\2\2\2\24n\3\2\2\2"+
		"\26\u0086\3\2\2\2\30\u008e\3\2\2\2\32\u009c\3\2\2\2\34\u00a7\3\2\2\2\36"+
		"\u00b7\3\2\2\2 \u00b9\3\2\2\2\"\u00c1\3\2\2\2$\u00ca\3\2\2\2&\u00db\3"+
		"\2\2\2(\u00dd\3\2\2\2*\u00e8\3\2\2\2,\u00ea\3\2\2\2.\u00ee\3\2\2\2\60"+
		"\u00f0\3\2\2\2\62\u00f2\3\2\2\2\64\u00f4\3\2\2\2\66\u00f6\3\2\2\289\5"+
		"\4\3\29:\5\6\4\2:\3\3\2\2\2;<\7\3\2\2<=\5*\26\2=>\7\36\2\2>@\3\2\2\2?"+
		";\3\2\2\2@C\3\2\2\2A?\3\2\2\2AB\3\2\2\2B\5\3\2\2\2CA\3\2\2\2DE\5.\30\2"+
		"EF\7\4\2\2FG\7(\2\2GH\7\33\2\2HI\5\b\5\2IJ\7\34\2\2J\7\3\2\2\2KL\5\n\6"+
		"\2LM\5\f\7\2M\t\3\2\2\2NP\5(\25\2ON\3\2\2\2PS\3\2\2\2QO\3\2\2\2QR\3\2"+
		"\2\2R\13\3\2\2\2SQ\3\2\2\2TU\7\5\2\2UY\7\33\2\2VX\5\16\b\2WV\3\2\2\2X"+
		"[\3\2\2\2YW\3\2\2\2YZ\3\2\2\2Z\\\3\2\2\2[Y\3\2\2\2\\]\7\34\2\2]\r\3\2"+
		"\2\2^c\5\22\n\2_c\5\24\13\2`c\5\26\f\2ac\5\30\r\2b^\3\2\2\2b_\3\2\2\2"+
		"b`\3\2\2\2ba\3\2\2\2c\17\3\2\2\2de\5\16\b\2e\21\3\2\2\2fg\7)\2\2gj\7\30"+
		"\2\2hk\5 \21\2ik\5\60\31\2jh\3\2\2\2ji\3\2\2\2kl\3\2\2\2lm\7\36\2\2m\23"+
		"\3\2\2\2no\7\b\2\2op\7\31\2\2pq\5 \21\2qr\7\32\2\2rs\7\n\2\2sw\7\33\2"+
		"\2tv\5\16\b\2ut\3\2\2\2vy\3\2\2\2wu\3\2\2\2wx\3\2\2\2xz\3\2\2\2yw\3\2"+
		"\2\2z\u0084\7\34\2\2{|\7\t\2\2|\u0080\7\33\2\2}\177\5\20\t\2~}\3\2\2\2"+
		"\177\u0082\3\2\2\2\u0080~\3\2\2\2\u0080\u0081\3\2\2\2\u0081\u0083\3\2"+
		"\2\2\u0082\u0080\3\2\2\2\u0083\u0085\7\34\2\2\u0084{\3\2\2\2\u0084\u0085"+
		"\3\2\2\2\u0085\25\3\2\2\2\u0086\u0087\7\6\2\2\u0087\u0088\7\31\2\2\u0088"+
		"\u0089\5\60\31\2\u0089\u008a\7\35\2\2\u008a\u008b\7)\2\2\u008b\u008c\7"+
		"\32\2\2\u008c\u008d\7\36\2\2\u008d\27\3\2\2\2\u008e\u008f\7\7\2\2\u008f"+
		"\u0090\7\31\2\2\u0090\u0095\5\60\31\2\u0091\u0092\7\35\2\2\u0092\u0094"+
		"\5 \21\2\u0093\u0091\3\2\2\2\u0094\u0097\3\2\2\2\u0095\u0093\3\2\2\2\u0095"+
		"\u0096\3\2\2\2\u0096\u0098\3\2\2\2\u0097\u0095\3\2\2\2\u0098\u0099\7\32"+
		"\2\2\u0099\u009a\7\36\2\2\u009a\31\3\2\2\2\u009b\u009d\7\f\2\2\u009c\u009b"+
		"\3\2\2\2\u009c\u009d\3\2\2\2\u009d\u009e\3\2\2\2\u009e\u00a4\5\34\17\2"+
		"\u009f\u00a0\5\66\34\2\u00a0\u00a1\5\34\17\2\u00a1\u00a3\3\2\2\2\u00a2"+
		"\u009f\3\2\2\2\u00a3\u00a6\3\2\2\2\u00a4\u00a2\3\2\2\2\u00a4\u00a5\3\2"+
		"\2\2\u00a5\33\3\2\2\2\u00a6\u00a4\3\2\2\2\u00a7\u00ad\5\36\20\2\u00a8"+
		"\u00a9\5\64\33\2\u00a9\u00aa\5\36\20\2\u00aa\u00ac\3\2\2\2\u00ab\u00a8"+
		"\3\2\2\2\u00ac\u00af\3\2\2\2\u00ad\u00ab\3\2\2\2\u00ad\u00ae\3\2\2\2\u00ae"+
		"\35\3\2\2\2\u00af\u00ad\3\2\2\2\u00b0\u00b8\7&\2\2\u00b1\u00b8\7\'\2\2"+
		"\u00b2\u00b8\7)\2\2\u00b3\u00b4\7\31\2\2\u00b4\u00b5\5\32\16\2\u00b5\u00b6"+
		"\7\32\2\2\u00b6\u00b8\3\2\2\2\u00b7\u00b0\3\2\2\2\u00b7\u00b1\3\2\2\2"+
		"\u00b7\u00b2\3\2\2\2\u00b7\u00b3\3\2\2\2\u00b8\37\3\2\2\2\u00b9\u00be"+
		"\5\"\22\2\u00ba\u00bb\7\27\2\2\u00bb\u00bd\5\"\22\2\u00bc\u00ba\3\2\2"+
		"\2\u00bd\u00c0\3\2\2\2\u00be\u00bc\3\2\2\2\u00be\u00bf\3\2\2\2\u00bf!"+
		"\3\2\2\2\u00c0\u00be\3\2\2\2\u00c1\u00c6\5$\23\2\u00c2\u00c3\7\26\2\2"+
		"\u00c3\u00c5\5$\23\2\u00c4\u00c2\3\2\2\2\u00c5\u00c8\3\2\2\2\u00c6\u00c4"+
		"\3\2\2\2\u00c6\u00c7\3\2\2\2\u00c7#\3\2\2\2\u00c8\u00c6\3\2\2\2\u00c9"+
		"\u00cb\7\25\2\2\u00ca\u00c9\3\2\2\2\u00ca\u00cb\3\2\2\2\u00cb\u00cc\3"+
		"\2\2\2\u00cc\u00cd\5&\24\2\u00cd%\3\2\2\2\u00ce\u00d4\5\32\16\2\u00cf"+
		"\u00d0\5\62\32\2\u00d0\u00d1\5\32\16\2\u00d1\u00d3\3\2\2\2\u00d2\u00cf"+
		"\3\2\2\2\u00d3\u00d6\3\2\2\2\u00d4\u00d2\3\2\2\2\u00d4\u00d5\3\2\2\2\u00d5"+
		"\u00dc\3\2\2\2\u00d6\u00d4\3\2\2\2\u00d7\u00d8\7\31\2\2\u00d8\u00d9\5"+
		" \21\2\u00d9\u00da\7\32\2\2\u00da\u00dc\3\2\2\2\u00db\u00ce\3\2\2\2\u00db"+
		"\u00d7\3\2\2\2\u00dc\'\3\2\2\2\u00dd\u00de\5,\27\2\u00de\u00e3\7)\2\2"+
		"\u00df\u00e0\7\35\2\2\u00e0\u00e2\7)\2\2\u00e1\u00df\3\2\2\2\u00e2\u00e5"+
		"\3\2\2\2\u00e3\u00e1\3\2\2\2\u00e3\u00e4\3\2\2\2\u00e4\u00e6\3\2\2\2\u00e5"+
		"\u00e3\3\2\2\2\u00e6\u00e7\7\36\2\2\u00e7)\3\2\2\2\u00e8\u00e9\t\2\2\2"+
		"\u00e9+\3\2\2\2\u00ea\u00eb\t\3\2\2\u00eb-\3\2\2\2\u00ec\u00ef\t\4\2\2"+
		"\u00ed\u00ef\3\2\2\2\u00ee\u00ec\3\2\2\2\u00ee\u00ed\3\2\2\2\u00ef/\3"+
		"\2\2\2\u00f0\u00f1\7*\2\2\u00f1\61\3\2\2\2\u00f2\u00f3\t\5\2\2\u00f3\63"+
		"\3\2\2\2\u00f4\u00f5\t\6\2\2\u00f5\65\3\2\2\2\u00f6\u00f7\t\7\2\2\u00f7"+
		"\67\3\2\2\2\26AQYbjw\u0080\u0084\u0095\u009c\u00a4\u00ad\u00b7\u00be\u00c6"+
		"\u00ca\u00d4\u00db\u00e3\u00ee";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}