// Generated from C:/Users/dell/IdeaProjects/TP_COMPIL\Small_Java.g4 by ANTLR 4.7.2
package com.gen;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link Small_JavaParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface Small_JavaVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#r}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitR(Small_JavaParser.RContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#import_bib}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitImport_bib(Small_JavaParser.Import_bibContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#class_declare}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_declare(Small_JavaParser.Class_declareContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#class_content}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClass_content(Small_JavaParser.Class_contentContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#vars_declare}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVars_declare(Small_JavaParser.Vars_declareContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#main}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMain(Small_JavaParser.MainContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#instruction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstruction(Small_JavaParser.InstructionContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#instruction2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstruction2(Small_JavaParser.Instruction2Context ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#assign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(Small_JavaParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#if_cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIf_cond(Small_JavaParser.If_condContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#read}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRead(Small_JavaParser.ReadContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#write}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrite(Small_JavaParser.WriteContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp(Small_JavaParser.ExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#factor}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFactor(Small_JavaParser.FactorContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#v}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitV(Small_JavaParser.VContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#exp_b}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp_b(Small_JavaParser.Exp_bContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#factor_b}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFactor_b(Small_JavaParser.Factor_bContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#literal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteral(Small_JavaParser.LiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtom(Small_JavaParser.AtomContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#var_declare}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVar_declare(Small_JavaParser.Var_declareContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#bibs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBibs(Small_JavaParser.BibsContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(Small_JavaParser.TypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#modif}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModif(Small_JavaParser.ModifContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString(Small_JavaParser.StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#op_compare}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp_compare(Small_JavaParser.Op_compareContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#mul_div}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMul_div(Small_JavaParser.Mul_divContext ctx);
	/**
	 * Visit a parse tree produced by {@link Small_JavaParser#plus_minus}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlus_minus(Small_JavaParser.Plus_minusContext ctx);
}